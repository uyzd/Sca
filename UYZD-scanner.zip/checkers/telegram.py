import httpx


def check_telegram_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.get(
            f"https://t.me/{username}",
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=8,
            follow_redirects=True,
        )
        if r.status_code == 429:
            return None, "rate_limit"
        if r.status_code == 404:
            return True, None
        if "tgme_page_extra" in r.text or "tgme_page_title" in r.text:
            return False, None
        if r.status_code == 200:
            return True, None
        return None, f"http_{r.status_code}"
    except Exception as e:
        return None, str(e)
