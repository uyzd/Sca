import httpx


def check_twitch_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.post(
            "https://gql.twitch.tv/gql",
            headers={"client-id": "kimne78kx3ncx6brgo4mv6wki5h1ko"},
            json=[{
                "operationName": "UsernameValidator_User",
                "variables": {"username": username},
                "extensions": {
                    "persistedQuery": {
                        "version": 1,
                        "sha256Hash": "fd1085cf8350e309b725cf8ca91cd90cac03909a3edeeedbd0872ac912f3d660",
                    }
                },
            }],
            timeout=8,
        )
        if r.status_code == 429:
            return None, "rate_limit"
        if '"isUsernameAvailable":true' in r.text:
            return True, None
        if r.status_code == 200:
            return False, None
        return None, f"http_{r.status_code}"
    except Exception as e:
        return None, str(e)
