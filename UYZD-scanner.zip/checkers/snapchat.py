import httpx


def check_snapchat_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.get(
            f"https://story.snapchat.com/s/{username}",
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=8,
            follow_redirects=True,
        )
        if r.status_code == 429:
            return None, "rate_limit"
        if r.status_code == 404:
            return True, None
        if r.status_code == 200:
            if "Sorry, this page isn" in r.text or "pageNotFound" in r.text:
                return True, None
            return False, None
        return None, f"http_{r.status_code}"
    except Exception as e:
        return None, str(e)
