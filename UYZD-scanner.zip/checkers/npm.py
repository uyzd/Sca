import httpx


def check_npm_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.get(
            f"https://registry.npmjs.org/-/user/org.couchdb.user:{username}",
            timeout=8,
        )
        if r.status_code == 429:
            return None, "rate_limit"
        if r.status_code == 404:
            return True, None
        if r.status_code == 200:
            return False, None
        return None, f"http_{r.status_code}"
    except Exception as e:
        return None, str(e)
