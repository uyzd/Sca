import httpx


def check_hackernews_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.get(
            f"https://hacker-news.firebaseio.com/v0/user/{username}.json",
            timeout=8,
        )
        if r.status_code == 429:
            return None, "rate_limit"
        if r.status_code == 200:
            if r.text.strip() == "null":
                return True, None
            return False, None
        return None, f"http_{r.status_code}"
    except Exception as e:
        return None, str(e)
