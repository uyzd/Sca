import os
import datetime
import requests

GENERAL_WEBHOOK_VAR = "WEBHOOK_URL"

PLATFORM_WEBHOOK_CONFIG: dict[str, tuple[str, str, int, str]] = {
    "xbox":           ("DISCORD_WEBHOOK_URL",      "✅ Xbox Username Available",           0x107C10, "Xbox"),
    "steam":          ("STEAM_WEBHOOK_URL",         "✅ Steam Username Available",          0x1B2838, "Steam"),
    "roblox":         ("ROBLOX_WEBHOOK_URL",        "✅ Roblox Username Available",         0xFF3E3E, "Roblox"),
    "discord":        ("DISCORD_WEBHOOK_URL_DC",    "✅ Discord Username Available",        0x5865F2, "Discord"),
    "chess":          ("CHESS_WEBHOOK_URL",         "✅ Chess.com Username Available",      0x769656, "Chess.com"),
    "discord_vanity": ("DISCORD_VANITY_WEBHOOK_URL","✅ Discord Vanity Available",          0x5865F2, "Discord Vanity"),
    "fortnite":       ("FORTNITE_WEBHOOK_URL",      "✅ Fortnite Username Available",       0x00D4FF, "Fortnite"),
    "github":         ("GITHUB_WEBHOOK_URL",        "✅ GitHub Username Available",         0x24292E, "GitHub"),
    "instagram":      ("INSTAGRAM_WEBHOOK_URL",     "✅ Instagram Username Available",      0xE1306C, "Instagram"),
    "kahoot":         ("KAHOOT_WEBHOOK_URL",        "✅ Kahoot Username Available",         0xFF3355, "Kahoot"),
    "lichess":        ("LICHESS_WEBHOOK_URL",        "✅ Lichess Username Available",       0xFFFFFF, "Lichess"),
    "minecraft":      ("MINECRAFT_WEBHOOK_URL",     "✅ Minecraft Username Available",      0x4CAF50, "Minecraft"),
    "pastebin":       ("PASTEBIN_WEBHOOK_URL",      "✅ Pastebin Username Available",       0x02A6F2, "Pastebin"),
    "replit":         ("REPLIT_WEBHOOK_URL",        "✅ Replit Username Available",         0xF26207, "Replit"),
    "solo":           ("SOLO_WEBHOOK_URL",          "✅ Solo.to Username Available",        0x00BCD4, "Solo.to"),
    "soundcloud":     ("SOUNDCLOUD_WEBHOOK_URL",    "✅ SoundCloud Username Available",     0xFF5500, "SoundCloud"),
    "speedrun":       ("SPEEDRUN_WEBHOOK_URL",      "✅ Speedrun.com Username Available",   0x00CB51, "Speedrun.com"),
    "tiktok":         ("TIKTOK_WEBHOOK_URL",        "✅ TikTok Username Available",         0x010101, "TikTok"),
    "twitter":        ("TWITTER_WEBHOOK_URL",       "✅ X / Twitter Username Available",    0x1DA1F2, "X / Twitter"),
    "youtube":        ("YOUTUBE_WEBHOOK_URL",       "✅ YouTube Handle Available",          0xFF0000, "YouTube"),
    "twitch":         ("TWITCH_WEBHOOK_URL",        "✅ Twitch Username Available",         0x9146FF, "Twitch"),
    "reddit":         ("REDDIT_WEBHOOK_URL",        "✅ Reddit Username Available",         0xFF4500, "Reddit"),
    "pinterest":      ("PINTEREST_WEBHOOK_URL",     "✅ Pinterest Username Available",      0xE60023, "Pinterest"),
    "telegram":       ("TELEGRAM_WEBHOOK_URL",      "✅ Telegram Username Available",       0x2CA5E0, "Telegram"),
    "tumblr":         ("TUMBLR_WEBHOOK_URL",        "✅ Tumblr Username Available",         0x35465C, "Tumblr"),
    "deviantart":     ("DEVIANTART_WEBHOOK_URL",    "✅ DeviantArt Username Available",     0x05CC47, "DeviantArt"),
    "gitlab":         ("GITLAB_WEBHOOK_URL",        "✅ GitLab Username Available",         0xFC6D26, "GitLab"),
    "medium":         ("MEDIUM_WEBHOOK_URL",        "✅ Medium Username Available",         0x000000, "Medium"),
    "letterboxd":     ("LETTERBOXD_WEBHOOK_URL",    "✅ Letterboxd Username Available",     0x00C030, "Letterboxd"),
    "lastfm":         ("LASTFM_WEBHOOK_URL",        "✅ Last.fm Username Available",        0xD51007, "Last.fm"),
    "bandcamp":       ("BANDCAMP_WEBHOOK_URL",      "✅ Bandcamp Username Available",       0x1DA0C3, "Bandcamp"),
    "dribbble":       ("DRIBBBLE_WEBHOOK_URL",      "✅ Dribbble Username Available",       0xEA4C89, "Dribbble"),
    "behance":        ("BEHANCE_WEBHOOK_URL",       "✅ Behance Username Available",        0x1769FF, "Behance"),
    "wattpad":        ("WATTPAD_WEBHOOK_URL",       "✅ Wattpad Username Available",        0xFF6122, "Wattpad"),
    "artstation":     ("ARTSTATION_WEBHOOK_URL",    "✅ ArtStation Username Available",     0x13AFF0, "ArtStation"),
    "kofi":           ("KOFI_WEBHOOK_URL",          "✅ Ko-fi Username Available",          0xFF5E5B, "Ko-fi"),
    "linktree":       ("LINKTREE_WEBHOOK_URL",      "✅ Linktree Username Available",       0x43E660, "Linktree"),
    "hackernews":     ("HACKERNEWS_WEBHOOK_URL",    "✅ Hacker News Username Available",    0xFF6600, "Hacker News"),
    "imgur":          ("IMGUR_WEBHOOK_URL",         "✅ Imgur Username Available",          0x1BB76E, "Imgur"),
    "npm":            ("NPM_WEBHOOK_URL",           "✅ NPM Username Available",            0xCB3837, "NPM"),
    "pypi":           ("PYPI_WEBHOOK_URL",          "✅ PyPI Username Available",           0x3775A9, "PyPI"),
    "newgrounds":     ("NEWGROUNDS_WEBHOOK_URL",    "✅ Newgrounds Username Available",     0xFFAA00, "Newgrounds"),
    "vk":             ("VK_WEBHOOK_URL",            "✅ VK Username Available",             0x4A76A8, "VK"),
    "producthunt":    ("PRODUCTHUNT_WEBHOOK_URL",   "✅ Product Hunt Username Available",   0xDA552F, "Product Hunt"),
    "snapchat":       ("SNAPCHAT_WEBHOOK_URL",      "✅ Snapchat Username Available",       0xFFFC00, "Snapchat"),
    "crunchyroll":    ("CRUNCHYROLL_WEBHOOK_URL",   "✅ Crunchyroll Username Available",    0xF47521, "Crunchyroll"),
}


def _get_webhook_url(platform: str, env_var: str) -> str:
    specific = os.environ.get(env_var, "").strip()
    if specific:
        return specific
    return os.environ.get(GENERAL_WEBHOOK_VAR, "").strip()


def post_platform_discord(username: str, platform: str) -> None:
    config = PLATFORM_WEBHOOK_CONFIG.get(platform)
    if not config:
        return
    env_var, title, color, footer = config
    webhook_url = _get_webhook_url(platform, env_var)
    if not webhook_url:
        return
    try:
        requests.post(
            webhook_url,
            json={
                "content": None,
                "embeds": [
                    {
                        "title": title,
                        "description": f"**`{username}`**",
                        "color": color,
                        "footer": {"text": f"{footer} Scanner"},
                        "timestamp": datetime.datetime.now(
                            datetime.timezone.utc
                        ).isoformat(),
                    }
                ],
            },
            timeout=5,
        )
    except Exception:
        pass


def post_discord(username: str) -> None:
    post_platform_discord(username, "xbox")
