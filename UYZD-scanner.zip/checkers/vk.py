import httpx


def check_vk_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.get(
            f"https://vk.com/{username}",
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=8,
            follow_redirects=True,
        )
        if r.status_code == 429:
            return None, "rate_limit"
        if r.status_code == 404:
            return True, None
        if "page_not_found" in r.text or "This page is private" not in r.text and "id=" not in r.url.path:
            if r.status_code == 200 and ('og:url' in r.text):
                return False, None
            return True, None
        return False, None
    except Exception as e:
        return None, str(e)
