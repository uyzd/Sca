import httpx


def check_wattpad_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.head(
            f"https://www.wattpad.com/user/{username}",
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=8,
            follow_redirects=True,
        )
        if r.status_code == 429:
            return None, "rate_limit"
        if r.status_code == 404:
            return True, None
        if r.status_code == 200:
            return False, None
        return None, f"http_{r.status_code}"
    except Exception as e:
        return None, str(e)
