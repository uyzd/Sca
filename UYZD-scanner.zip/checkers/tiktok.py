import httpx


def check_tiktok_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.get(
            f"https://www.tiktok.com/@{username}",
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=10,
            follow_redirects=True,
        )
        if r.status_code == 429:
            return None, "rate_limit"
        if r.status_code == 404:
            return True, None
        if '"statusCode":10202' in r.text or "couldn\u2019t find this account" in r.text.lower():
            return True, None
        if r.status_code == 200:
            return False, None
        return None, f"http_{r.status_code}"
    except Exception as e:
        return None, str(e)
