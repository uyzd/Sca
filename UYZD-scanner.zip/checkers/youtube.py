import httpx


def check_youtube_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.head(
            f"https://www.youtube.com/@{username}",
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=8,
        )
        if r.status_code == 429:
            return None, "rate_limit"
        if r.status_code == 404:
            return True, None
        return False, None
    except Exception as e:
        return None, str(e)
