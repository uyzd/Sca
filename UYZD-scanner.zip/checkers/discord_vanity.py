import httpx


def check_discord_vanity(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.head(f"https://discord.com/api/v10/invites/{username}", timeout=8)
        if r.status_code == 429:
            return None, "rate_limit"
        if r.status_code == 404:
            return True, None
        return False, None
    except Exception as e:
        return None, str(e)
