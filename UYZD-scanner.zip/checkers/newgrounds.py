import httpx


def check_newgrounds_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.head(
            f"https://{username}.newgrounds.com",
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=8,
            follow_redirects=True,
        )
        if r.status_code == 429:
            return None, "rate_limit"
        if r.status_code == 404:
            return True, None
        if r.status_code in (200, 301, 302):
            return False, None
        return None, f"http_{r.status_code}"
    except Exception as e:
        return None, str(e)
