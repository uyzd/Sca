import httpx


def check_fortnite_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.get(f"https://fortnite.gg/stats?player={username}", timeout=10)
        if r.status_code == 429:
            return None, "rate_limit"
        if f'I can\'t find a player named \u201c{username}\u201d' in r.text or "No player found" in r.text:
            return True, None
        if r.status_code == 404:
            return True, None
        return False, None
    except Exception as e:
        return None, str(e)
