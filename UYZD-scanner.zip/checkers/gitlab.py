import httpx


def check_gitlab_username(username: str) -> tuple[bool | None, str | None]:
    try:
        r = httpx.get(
            f"https://gitlab.com/api/v4/users?username={username}",
            timeout=8,
        )
        if r.status_code == 429:
            return None, "rate_limit"
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, list) and len(data) == 0:
                return True, None
            return False, None
        return None, f"http_{r.status_code}"
    except Exception as e:
        return None, str(e)
