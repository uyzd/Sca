import os
import random


class ProxyManager:
    def __init__(self) -> None:
        self._proxies: list[str] = []
        self._idx: int = 0

    def load_from_file(self, path: str) -> int:
        try:
            with open(path) as f:
                lines = [l.strip() for l in f if l.strip() and not l.startswith("#")]
            self._proxies = lines
            self._idx = 0
            return len(lines)
        except FileNotFoundError:
            return 0

    def set_manual(self, proxies: list[str]) -> None:
        self._proxies = [p.strip() for p in proxies if p.strip()]
        self._idx = 0

    def clear(self) -> None:
        self._proxies = []
        self._idx = 0
        for var in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
                    "http_proxy", "https_proxy", "all_proxy"):
            os.environ.pop(var, None)

    def apply(self) -> None:
        if not self._proxies:
            return
        proxy = self._proxies[self._idx % len(self._proxies)]
        self._idx += 1
        if not proxy.startswith(("http://", "https://", "socks5://")):
            proxy = "http://" + proxy
        for var in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
                    "http_proxy", "https_proxy", "all_proxy"):
            os.environ[var] = proxy

    def rotate(self) -> None:
        if self._proxies:
            self.apply()

    @property
    def active(self) -> bool:
        return bool(self._proxies)

    @property
    def count(self) -> int:
        return len(self._proxies)


proxy_manager = ProxyManager()
