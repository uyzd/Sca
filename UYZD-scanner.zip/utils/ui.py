import os
from rich.console import Console
from rich.text import Text
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.rule import Rule

console = Console()

RAINBOW = [
    "bold bright_cyan",
    "bold bright_magenta",
    "bold bright_blue",
    "bold cyan",
    "bold magenta",
    "bold bright_cyan",
]

ASCII_LINES = [
    r" ██╗   ██╗██╗   ██╗███████╗██████╗ ",
    r" ██║   ██║╚██╗ ██╔╝╚════██║██╔══██╗",
    r" ██║   ██║ ╚████╔╝     ██╔╝██║  ██║",
    r" ╚██╗ ██╔╝  ╚██╔╝     ██╔╝ ██║  ██║",
    r"  ╚████╔╝    ██║      ██╔╝  ██████╔╝",
    r"   ╚═══╝     ╚═╝      ╚═╝   ╚═════╝ ",
]

API_CONFIG = [
    ("XBL_API_KEY",    "Xbox API key",      "bright_green",  True),
    ("STEAM_API_KEY",  "Steam API key",     "bright_blue",   False),
    ("ROBLOX_COOKIE",  "Roblox cookie",     "bright_red",    False),
    ("DISCORD_TOKEN",  "Discord token",     "light_violet",  True),
]

PLATFORM_OVERRIDE_WEBHOOKS = [
    ("Xbox",           "DISCORD_WEBHOOK_URL",       "bright_green"),
    ("Steam",          "STEAM_WEBHOOK_URL",          "bright_blue"),
    ("Roblox",         "ROBLOX_WEBHOOK_URL",         "bright_red"),
    ("Discord",        "DISCORD_WEBHOOK_URL_DC",     "light_violet"),
    ("Chess.com",      "CHESS_WEBHOOK_URL",          "white"),
    ("Discord Vanity", "DISCORD_VANITY_WEBHOOK_URL", "light_violet"),
    ("Fortnite",       "FORTNITE_WEBHOOK_URL",       "bright_cyan"),
    ("GitHub",         "GITHUB_WEBHOOK_URL",         "white"),
    ("Instagram",      "INSTAGRAM_WEBHOOK_URL",      "bright_magenta"),
    ("Kahoot",         "KAHOOT_WEBHOOK_URL",         "bright_red"),
    ("Lichess",        "LICHESS_WEBHOOK_URL",        "white"),
    ("Minecraft",      "MINECRAFT_WEBHOOK_URL",      "bright_green"),
    ("Pastebin",       "PASTEBIN_WEBHOOK_URL",       "bright_blue"),
    ("Replit",         "REPLIT_WEBHOOK_URL",         "bright_red"),
    ("Solo.to",        "SOLO_WEBHOOK_URL",           "bright_cyan"),
    ("SoundCloud",     "SOUNDCLOUD_WEBHOOK_URL",     "bright_red"),
    ("Speedrun.com",   "SPEEDRUN_WEBHOOK_URL",       "bright_green"),
    ("TikTok",         "TIKTOK_WEBHOOK_URL",         "white"),
    ("Twitter / X",    "TWITTER_WEBHOOK_URL",        "bright_blue"),
    ("YouTube",        "YOUTUBE_WEBHOOK_URL",        "bright_red"),
    ("Twitch",         "TWITCH_WEBHOOK_URL",         "light_violet"),
    ("Reddit",         "REDDIT_WEBHOOK_URL",         "bright_red"),
    ("Pinterest",      "PINTEREST_WEBHOOK_URL",      "bright_red"),
    ("Telegram",       "TELEGRAM_WEBHOOK_URL",       "bright_blue"),
    ("Tumblr",         "TUMBLR_WEBHOOK_URL",         "white"),
    ("DeviantArt",     "DEVIANTART_WEBHOOK_URL",     "bright_green"),
    ("GitLab",         "GITLAB_WEBHOOK_URL",         "bright_red"),
    ("Medium",         "MEDIUM_WEBHOOK_URL",         "white"),
    ("Letterboxd",     "LETTERBOXD_WEBHOOK_URL",     "bright_green"),
    ("Last.fm",        "LASTFM_WEBHOOK_URL",         "bright_red"),
    ("Bandcamp",       "BANDCAMP_WEBHOOK_URL",       "bright_cyan"),
    ("Dribbble",       "DRIBBBLE_WEBHOOK_URL",       "bright_magenta"),
    ("Behance",        "BEHANCE_WEBHOOK_URL",        "bright_blue"),
    ("Wattpad",        "WATTPAD_WEBHOOK_URL",        "bright_red"),
    ("ArtStation",     "ARTSTATION_WEBHOOK_URL",     "bright_cyan"),
    ("Ko-fi",          "KOFI_WEBHOOK_URL",           "bright_red"),
    ("Linktree",       "LINKTREE_WEBHOOK_URL",       "bright_green"),
    ("Hacker News",    "HACKERNEWS_WEBHOOK_URL",     "bright_red"),
    ("Imgur",          "IMGUR_WEBHOOK_URL",          "bright_green"),
    ("NPM",            "NPM_WEBHOOK_URL",            "bright_red"),
    ("PyPI",           "PYPI_WEBHOOK_URL",           "bright_blue"),
    ("Newgrounds",     "NEWGROUNDS_WEBHOOK_URL",     "bright_red"),
    ("VK",             "VK_WEBHOOK_URL",             "bright_blue"),
    ("Product Hunt",   "PRODUCTHUNT_WEBHOOK_URL",    "bright_red"),
    ("Snapchat",       "SNAPCHAT_WEBHOOK_URL",       "bright_yellow"),
    ("Crunchyroll",    "CRUNCHYROLL_WEBHOOK_URL",    "bright_red"),
]


def print_banner() -> None:
    console.clear()
    art = Text()
    for i, line in enumerate(ASCII_LINES):
        art.append(line + "\n", style=RAINBOW[i % len(RAINBOW)])
    console.print(art, justify="center")

    sub = Text()
    sub.append("Username Scanner", style="bold bright_green")
    sub.append("  ·  ", style="dim white")
    sub.append("46 platforms  →  posts to Discord", style="dim cyan")
    console.print(sub, justify="center")
    console.print()

    console.print(Rule("[dim]API Keys[/]", style="dim bright_cyan"))
    api_table = Table(
        box=box.SIMPLE,
        border_style="dim",
        show_header=False,
        padding=(0, 2),
        expand=False,
    )
    api_table.add_column("icon",  style="bold",       no_wrap=True)
    api_table.add_column("label", style="dim white",  no_wrap=True)
    api_table.add_column("var",   style="dim yellow", no_wrap=True)

    for env_var, label, color, required in API_CONFIG:
        val = os.environ.get(env_var, "")
        if val:
            icon  = Text("✓", style="bold bright_green")
            ltext = Text(f"{label} loaded", style=color)
            vtext = Text("")
        elif required:
            icon  = Text("✗", style="bold red")
            ltext = Text(f"{label} missing", style="red")
            vtext = Text(env_var, style="dim yellow")
        else:
            icon  = Text("✓", style="bold bright_green")
            ltext = Text(f"{label}", style=color)
            vtext = Text("no key needed", style="dim")
        api_table.add_row(icon, ltext, vtext)

    console.print(api_table, justify="center")
    console.print()

    console.print(Rule("[dim]Discord Webhooks[/]", style="dim bright_cyan"))

    general_url = os.environ.get("WEBHOOK_URL", "").strip()

    wh_table = Table(
        box=box.SIMPLE_HEAVY,
        border_style="bright_cyan",
        show_header=True,
        header_style="bold bright_cyan",
        padding=(0, 2),
        expand=False,
    )
    wh_table.add_column("Scope",    style="bold white", no_wrap=True)
    wh_table.add_column("Env Var",  style="dim yellow", no_wrap=True, min_width=24)
    wh_table.add_column("Status",   no_wrap=True)

    if general_url:
        masked = general_url[:38] + "…" if len(general_url) > 39 else general_url
        wh_table.add_row(
            Text("All Platforms", style="bold bright_green"),
            Text("WEBHOOK_URL", style="bright_yellow"),
            Text("● set  (all 46 platforms post here)", style="bold bright_green"),
        )
    else:
        wh_table.add_row(
            Text("All Platforms", style="dim white"),
            Text("WEBHOOK_URL", style="dim yellow"),
            Text("○ not set", style="dim red"),
        )

    active_overrides = [(n, v, c) for n, v, c in PLATFORM_OVERRIDE_WEBHOOKS if os.environ.get(v, "").strip()]
    if active_overrides:
        wh_table.add_row(Text(""), Text(""), Text(""))
        wh_table.add_row(
            Text("Platform Overrides", style="bold bright_cyan"),
            Text(""), Text(""),
        )
        for name, var, color in active_overrides:
            wh_table.add_row(
                Text(f"  {name}", style=color),
                Text(var, style="dim yellow"),
                Text("● set", style="bold bright_green"),
            )
    else:
        not_set_count = len(PLATFORM_OVERRIDE_WEBHOOKS)
        wh_table.add_row(
            Text("Platform Overrides", style="dim white"),
            Text("e.g. GITHUB_WEBHOOK_URL", style="dim yellow"),
            Text(f"○ none set  ({not_set_count} available)", style="dim"),
        )

    console.print(wh_table, justify="center")
    console.print()


def ask(question: str, default: str, choices: list[str] | None = None) -> str:
    t = Text()
    t.append("[ ",  style="dim white")
    t.append("? ",  style="bold bright_cyan")
    t.append("] ",  style="dim white")
    t.append(question, style="bold white")
    t.append(f" (default: {default}) ", style="dim white")
    t.append(f"({default})", style="bold bright_cyan")
    t.append(": ", style="dim white")
    console.print(t, end="")
    raw = input().strip()
    if not raw:
        return default
    if choices:
        return raw.lower() if raw.lower() in choices else default
    return raw


def ask_choice(question: str, options: list[tuple[str, str]], default: str) -> str:
    t = Text()
    t.append(f"\n  {question}\n", style="bold white")
    console.print(t)
    for key, desc in options:
        mark = "bold bright_cyan" if key == default else "dim white"
        row = Text()
        row.append(f"    [{key}] ", style=mark)
        row.append(desc, style="dim white" if key != default else "white")
        console.print(row)
    console.print()
    t2 = Text()
    t2.append("[ ",  style="dim white")
    t2.append("? ",  style="bold bright_cyan")
    t2.append("] ",  style="dim white")
    t2.append("Choose mode", style="bold white")
    t2.append(f" ({default})", style="bold bright_cyan")
    t2.append(": ", style="dim white")
    console.print(t2, end="")
    raw = input().strip().lower()
    valid = {k for k, _ in options}
    return raw if raw in valid else default


def ask_yn(question: str, default: str = "y") -> bool:
    t = Text()
    t.append("[ ",  style="dim white")
    t.append("? ",  style="bold bright_cyan")
    t.append("] ",  style="dim white")
    t.append(question, style="bold white")
    t.append(" [y/n] ", style="dim white")
    t.append(f"({default})", style="bold bright_cyan")
    t.append(": ", style="dim white")
    console.print(t, end="")
    raw = input().strip().lower()
    if raw not in ("y", "n"):
        return default == "y"
    return raw == "y"
